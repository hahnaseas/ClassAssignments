/*
const box = document.querySelector('.box');
box.style.display = 'none';
*/

$jQuery('.box').hide();