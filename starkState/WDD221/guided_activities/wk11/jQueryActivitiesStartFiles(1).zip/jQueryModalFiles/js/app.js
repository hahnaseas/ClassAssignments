// jQuery code for a modal

